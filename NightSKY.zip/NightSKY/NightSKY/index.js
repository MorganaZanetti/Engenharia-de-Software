const http = require('http');
const express = require('express');
const { render } = require('ejs');
const MongoClient = require("mongodb").MongoClient;
const bcrypt = require('bcrypt');

const uri = `mongodb+srv://orlandonagrockis:onabe123@nightsky.s4il00r.mongodb.net/?appName=NightSKY`;

const client = new MongoClient(uri, { useNewUrlParser: true});

var app = express();
app.use(express.static('./public'));
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

async function startServer() {
    try {
        await client.connect();
        console.log("Conectado ao MongoDB com sucesso");
        const usuario = client.db("NightSKY").collection("Usuário");
        await usuario.createIndex({db_email: 1}, {unique: true});
        app.listen(3000, () => {
            console.log('Servidor iniciado na porta 3000');
        });
    } catch (err) {
        console.error("Não foi possível iniciar o servidor", err);
        process.exit(1);
    }
}

app.get('/', (req, res) => {
    res.render("login_usuario.ejs", { resposta: "" });
});

app.get('/voltarlogin', function (req, res){
    res.render("login_usuario.ejs", {resposta: ""});
})

app.get('/voltarcadastro_jogador', function (req, res){
    res.render("cadastro_jogador.ejs", { resposta: "" });
})

app.get('/voltarcadastro_dev', function (req, res){
    res.render("cadastro_dev.ejs", { resposta: "" });
})

app.get('/voltarcadastro_publisher', function (req, res){
    res.render("cadastro_publisher.ejs", { resposta: "" });
})

app.post("/cadastrar_jogador", async (req, resp) => {
    try {
        const hash = await bcrypt.hash(req.body.senha, 10);
        await client.db("NightSKY").collection("Usuário").insertOne(
            {db_nome: req.body.nome, db_email: req.body.email, db_senha: hash, db_tipo_conta: "Jogador"}
        )
        resp.render('catalogo', {resposta: "Catálogo de jogos"})
    }
    catch (err) {
        resp.render('cadastro_jogador', {resposta: "Erro ao cadastrar jogador!"})
    }
});

app.post("/cadastrar_dev", async (req, resp) => {
    try {
        const hash = await bcrypt.hash(req.body.senha, 10);
        await client.db("NightSKY").collection("Usuário").insertOne(
            {db_nome: req.body.nome, db_email: req.body.email, db_senha: hash, db_tipo_conta: "Dev"}
        )
        resp.render('catalogo', {resposta: "Catálogo de jogos"})
    }
    catch (err) {
        resp.render('cadastro_dev', {resposta: "Erro ao cadastrar desenvolvedor!"})
    }
});

app.post("/cadastrar_publisher", async (req, resp) => {
    try {
        const hash = await bcrypt.hash(req.body.senha, 10);
        await client.db("NightSKY").collection("Usuário").insertOne(
            {db_nome: req.body.nome, db_email: req.body.email, db_senha: hash, db_cnpj: req.body.cnpj, db_tipo_conta: "Publisher"}
        )
        resp.render('catalogo', {resposta: "Catálogo de jogos"})
    }
    catch (err) {
        resp.render('cadastro_jogador', {resposta: "Erro ao cadastrar publisher!"})
    }
});

app.post("/logar_usuario", async (req, resp) => {
    try {
        const verificar_email = await client.db("NightSKY").collection("Usuário").findOne(
            {db_email: req.body.email}
        )
        if(!verificar_email){
            return resp.render('login_usuario', {resposta: "Email não encontrado!"})
        }
        const verificar_senha = await bcrypt.compare(req.body.senha, verificar_email.db_senha);
        if(!verificar_senha){
            return resp.render('login_usuario', {resposta: "Senha errada!"})
        }
        resp.render('catalogo', {resposta: "Catálogo de jogos"})
    }
    catch (err) {
        resp.render('login_usuario', {resposta: "Erro ao logar!"})
    }
});

startServer();