**COMO USAR O NIGHTSKY**



Baixe o arquivo NightSKYFinal.zip



Descompacte o arquivo e execute o NightSKY seguindo as seguintes instruções:



Passo 1. Abrir a pasta NightSky.



Passo 2. Executar o arquivo nightsky(.bat)

