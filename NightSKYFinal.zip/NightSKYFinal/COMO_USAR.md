**COMO USAR O NIGHTSKY**



1. Para iniciar o servidor, dê dois cliques no arquivo nightsky (o arquivo do tipo Aplicativo).
   
2. Uma janela de Terminal irá se abrir e deve exibir a mensagem "Servidor iniciado".
   
3. Não feche a janela do Terminal.
   
4. Abra seu navegador (Chrome, Firefox, Edge, etc.).
   
5. Na barra de endereço, digite: localhost:3000.
